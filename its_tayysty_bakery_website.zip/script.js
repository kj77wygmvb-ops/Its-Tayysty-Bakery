document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const toggle = document.querySelector(".menu-toggle");
  const nav = document.getElementById("main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    nav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const form = document.getElementById("inquiry-form");
  if (!form) return;

  // Pre-fill the inquiry form when someone clicks an order button from the shop.
  const params = new URLSearchParams(window.location.search);
  const item = params.get("item");
  const quantity = params.get("quantity");
  const bundle = params.get("bundle");
  const details = document.getElementById("details");
  const quantityInput = document.getElementById("quantity");
  const type = document.getElementById("type");

  if (quantity && quantityInput) quantityInput.value = quantity;
  if (item && details) details.value = `I'd like to order ${bundle || ""} of ${item}.`;
  if (type && item) type.value = "Cookies";

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const data = new FormData(form);
    const name = data.get("name");
    const email = data.get("email");
    const phone = data.get("phone") || "Not provided";
    const date = data.get("date") || "Not provided";
    const orderType = data.get("type");
    const quantity = data.get("quantity") || "Not provided";
    const occasion = data.get("occasion") || "Not provided";
    const budget = data.get("budget") || "Not provided";
    const details = data.get("details");
    const inspiration = data.get("inspiration") || "Not provided";

    const subject = `It's Tayysty Inquiry — ${orderType}`;
    const body =
`Hello It's Tayysty Bakery!

I'd like to inquire about an order.

Name: ${name}
Email: ${email}
Phone: ${phone}
Event date: ${date}
Order type: ${orderType}
Estimated quantity: ${quantity}
Event / occasion: ${occasion}
Budget: ${budget}

Order details:
${details}

Inspiration link:
${inspiration}

Thank you!`;

    const mailto = `mailto:itstayysty@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    const status = document.getElementById("form-status");

    status.textContent = "Your email draft is ready. If it didn't open, use the email address shown below.";
    window.location.href = mailto;
  });
});
