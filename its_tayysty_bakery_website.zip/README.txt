# It's Tayysty Bakery Website

A responsive, accessibility-conscious bakery website for It's Tayysty Bakery.

## Included
- `index.html` — homepage, cookie offer, about section, custom dessert section
- `inquiry.html` — larger-order and custom-dessert inquiry form
- `styles.css` — responsive black/red/white/cheetah-inspired design
- `script.js` — mobile menu, year, and email inquiry behavior
- `assets/its-tayysty-logo.jpg` — logo extracted from the uploaded image

## Important
The inquiry form does not pretend to have a backend. When submitted, it opens the visitor's email app with a prepared inquiry addressed to:

itstayysty@gmail.com

## Publishing
This is a static website and can be published on GitHub Pages, Netlify, Vercel, or another static hosting service. Upload the contents of this folder while keeping the `assets` folder beside the HTML files.

## Editing
Search the HTML files for prices, contact information, service details, or wording you want to change.
